<?php
/*Configuration Settings*/

define('DB_HOST', 'localhost'); /*Database Server*/
define('DB_NAME', 'formcollector'); /*Database Name*/
define('DB_USER', 'root'); /*Database Username*/
define('DB_PWD',  ''); /*Database Password*/

?>