<?php
include('session.php');
?>
<!-- iframe will pull in the contents of index.php inside -->
<iframe src="index.php" width="100%" height="100%"></iframe>

